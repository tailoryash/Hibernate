package com.simform.ecommerceapi.dto;

import lombok.Data;

@Data
public class OrdersDto {
    private int id;

    private String productName;

}
